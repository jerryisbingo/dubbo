package com.cb.service.inter;

public interface SayHello {

	String hello();
	
}
