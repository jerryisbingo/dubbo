package com.cb.service.impl;

import org.springframework.stereotype.Service;

import com.cb.service.inter.SayHello;

@Service
public class SayHelloImpl implements SayHello{

	@Override
	public String hello() {
		// TODO Auto-generated method stub
		return "dubbo hello";
	}

}
