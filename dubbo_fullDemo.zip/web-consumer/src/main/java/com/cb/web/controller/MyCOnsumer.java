package com.cb.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cb.service.inter.SayHello;

@Controller
public class MyCOnsumer {

	@Autowired
	private SayHello sayHello;
	
	@RequestMapping("/say")
	@ResponseBody
	public String say()
	{
      return sayHello.hello();		
	}
	
}
